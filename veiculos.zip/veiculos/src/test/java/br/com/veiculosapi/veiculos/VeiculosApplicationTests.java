package br.com.veiculosapi.veiculos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VeiculosApplicationTests {

	@Test
	void contextLoads() {
	}

}
